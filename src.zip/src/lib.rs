//! # certgen
//!
//! A library and CLI tool for generating certificates from ODF templates.
//!
//! ## Features
//!
//! - Fill ODF documents with custom data
//! - Batch processing from JSON files
//! - Extensible placeholder system
//!
//! ## Example
//!
//! ```rust,no_run
//! use certgen::{OdfDocument, CertificateData};
//!
//! let doc = OdfDocument::open("template.odt").unwrap();
//! let data = CertificateData::new(
//!     "Max Mustermann".to_string(),
//!     "15.01.2024".to_string(),
//!     "Rust Workshop".to_string(),
//! );
//!
//! doc.fill_and_save("output.odt", &data.to_replacements()).unwrap();
//! ```

pub mod error;
pub mod odf;
pub mod template;
pub mod cli;

// Re-exports für einfachere Verwendung
pub use error::{CertgenError, Result};
pub use odf::{OdfDocument, PlaceholderReplacer};
pub use template::CertificateData;
pub use cli::{Cli, Commands};
