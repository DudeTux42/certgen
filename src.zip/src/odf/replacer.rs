use std::collections::HashMap;
use log::{debug, warn};

/// Ersetzt Platzhalter im Text
pub struct PlaceholderReplacer {
    prefix: String,
    suffix: String,
}

impl PlaceholderReplacer {
    /// Erstellt einen neuen Replacer mit Standard-Platzhalter-Format {{KEY}}
    pub fn new() -> Self {
        Self {
            prefix: "{{".to_string(),
            suffix: "}}".to_string(),
        }
    }

    /// Erstellt einen Replacer mit benutzerdefiniertem Format
    pub fn with_format(prefix: String, suffix: String) -> Self {
        Self { prefix, suffix }
    }

    /// Ersetzt alle Platzhalter im gegebenen Text
    pub fn replace_all(&self, content: &str, replacements: &HashMap<String, String>) -> String {
        let mut result = content.to_string();
        
        for (key, value) in replacements {
            let placeholder = format!("{}{}{}", self.prefix, key, self.suffix);
            let count = result.matches(&placeholder).count();
            
            if count > 0 {
                debug!("Replacing {} occurrences of '{}'", count, placeholder);
                result = result.replace(&placeholder, value);
            } else {
                warn!("Placeholder '{}' not found in document", placeholder);
            }
        }
        
        result
    }

    /// Findet alle Platzhalter im Text
    pub fn find_placeholders(&self, content: &str) -> Vec<String> {
        let mut placeholders = Vec::new();
        let mut chars = content.chars().peekable();
        let prefix_chars: Vec<char> = self.prefix.chars().collect();
        let suffix_chars: Vec<char> = self.suffix.chars().collect();
        
        while let Some(_) = chars.peek() {
            // Einfache Implementierung - könnte optimiert werden
            if let Some(start) = content.find(&self.prefix) {
                if let Some(end) = content[start..].find(&self.suffix) {
                    let placeholder = &content[start + self.prefix.len()..start + end];
                    if !placeholders.contains(&placeholder.to_string()) {
                        placeholders.push(placeholder.to_string());
                    }
                }
            }
            break;
        }
        
        placeholders
    }
}

impl Default for PlaceholderReplacer {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_replace_all() {
        let replacer = PlaceholderReplacer::new();
        let mut replacements = HashMap::new();
        replacements.insert("NAME".to_string(), "Max".to_string());
        replacements.insert("DATE".to_string(), "2024".to_string());
        
        let content = "Hello {{NAME}} from {{DATE}}!";
        let result = replacer.replace_all(content, &replacements);
        
        assert_eq!(result, "Hello Max from 2024!");
    }

    #[test]
    fn test_custom_format() {
        let replacer = PlaceholderReplacer::with_format("[[".to_string(), "]]".to_string());
        let mut replacements = HashMap::new();
        replacements.insert("KEY".to_string(), "value".to_string());
        
        let content = "Test [[KEY]] here";
        let result = replacer.replace_all(content, &replacements);
        
        assert_eq!(result, "Test value here");
    }
}
